select * from table (cast (f_int_date_varchar2() as table_int_date_varchar2))
