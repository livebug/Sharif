select a, b, c, d, e, 1, 2, f(a,b,c,1+1) from dual

