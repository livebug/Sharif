-- Test for RENAME statement of unit_statement (f.e. renaming Oracle jobs)
RENAME FOO TO BAR;
