select * from dual,( dual left outer join tt2 using(dummy) )

