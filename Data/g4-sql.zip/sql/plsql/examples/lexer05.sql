select tbl$or$idx$part$num("sys"."wrh:_seg_stat",0,4,0,"rowid") as c1 from t1
