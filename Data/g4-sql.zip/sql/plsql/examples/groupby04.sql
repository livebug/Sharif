select * from x
group by grouping sets
( (a),1 )
