ALTER VIEW customer_ro
    COMPILE; 
ALTER VIEW customer_ro
    EDITIONABLE;
