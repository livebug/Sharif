AUDIT POLICY table_pol;
AUDIT POLICY dml_pol BY hr, sh;

