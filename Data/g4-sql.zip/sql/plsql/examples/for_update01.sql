select employee_id from (select * from employees)
   for update of employee_id


