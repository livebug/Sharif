select d1.*, d2.* from dual d1 cross join dual d2
