call dbms_scheduler.auto_purge (  )
