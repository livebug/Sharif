Sample scripts taken from https://github.com/postgres/postgres/tree/master/src/test/regress/sql
