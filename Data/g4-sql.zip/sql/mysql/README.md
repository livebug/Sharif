# MySQL grammars

This folder contains MySQL grammars from different authors. See the specific sub folders for more details:

- [Oracle](Oracle) - A complete grammar, mostly derived from the MySQL server grammar (5.6, 5.7, 8.0), as used in MySQL Workbench
- [Positive Technologies](Positive-Technologies) - A grammar created from the official documentation (5.6, 5.7)
