SeleCT * frOm someID whErE someexpr > coname orDer bY 1;
upDaTe tbl SeT col=11 wherE col2 > 1;
DeleTE t1.*, t2 from t1 join t3 on t1.col1 = t3.col1 jOin t2 oN t2.col2 = t3.col2 where t3.co4 is NoT nULl;
InsERT iNtO t(coL1, cOl2, CoL3, Col4) ValUes (1, 2, 3, 4), (sQRt(5), aBs(10-poWeR(3,4)), cEIL(rAnD()*100) , (sIn(0.5*3.413234) + coS(100 MoD 33)) +lOG(pI()*eXp(AcOS(10)*AtAn(10)))  );